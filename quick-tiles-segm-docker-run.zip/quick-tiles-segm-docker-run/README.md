# Quick tiling segmentation


### Как запустить программу из Docker Hub при наличии настроенной системы (кратко).
1. Cоздать папку для приложения и перейти в нее:
```bash
mkdir -p quick-tiles-segm
cd quick-tiles-segm
```
2. Создать папку models и положить в нее файл весов модели, который можно взять по ссылке:
```
https://disk.yandex.ru/d/cMsiauLhyvhsgg
```
3. Создать папки для исходных и готовых изображений source_files и out_files.
```bash
mkdir -p source_files out_files
```  
4. Создать файл docker-compose.yaml с содержимым:
```
services:
  app:
    image: segm-tiles-image
    env_file: cfg.env
    volumes:
      - ./source_files:/app/source_files
      - ./out_files:/app/out_files
      - ./models:/app/models
    command: python src/app.py test
    runtime: nvidia
    environment:
      - NVIDIA_VISIBLE_DEVICES=all
```
5. Создать файл с настройками cfg.env: 
```
# Переменные окружения должны иметь имя APP_ + имя переменной в верхнем регистре
# Параметр False надо передавать пустой строкой: ""

# Выводить дополнительную информацию
APP_VERBOSE="True"

# Использовать GPU
APP_SAM2_FORCE_CUDA="True"
```
6. Запустить программу в тестовом режиме командой:
```bash
docker compose up
```
При первом запуске образ будет автоматически загружен с Docker Hub.

6. В папку source_files помещаем изображение для обработки и запускаем программу в рабочем режиме:  
```bash
docker compose run app python src/app.py baseline
```
```bash
docker compose run app python src/app.py tiling
```

Примечание:  
Архив quick-tiles-segm-docker-run.zip содержит минимальный набор файлов для запуска приложения из готового образа
(веса модели надо скачать как описано выше).
```bash
unzip quick-tiles-segm-docker-run.zip
cd unzip quick-tiles-segm-docker-run
```


### Образ, работающий только на CPU. 

Команда запуска приложения на CPU в docker compose в режиме baseline.
```bash
docker compose -f docker-compose-cpu.yaml run app python src/app.py baseline
```
Примечание:
```
Работа приложения без использования NVIDIA будет медненней в несколько раз. 
Использование приложения без GPU не рекомендуется для практического применения, но с его помощью можно
проверить работоспобность остальных компонентов системы.
```

